<?php
/**
 * russian.php
 * Файл локализации плагина Estheme
 *
 * @author      Андрей Воронов <andreyv@gladcode.ru>
 * @copyrights  Copyright © 2015, Андрей Воронов
 *              Является частью плагина Estheme
 * @version     0.0.1 от 27.02.2015 08:56
 */

return array(
    'admin_title' => 'Настройка шаблона "Experience simple"',
    'cancel'      => 'Отменить',
    'save'        => 'Сохранить текущую тему',
);