<?php

/**
 * Estheme.class.php
 * Файл модуля Estheme плагина Estheme
 *
 * @author      Андрей Воронов <andreyv@gladcode.ru>
 * @copyrights  Copyright © 2015, Андрей Воронов
 *              Является частью плагина Estheme
 * @version     0.0.1 от 27.02.2015 08:56
 */
class PluginEstheme_ModuleEstheme extends Module {
    /**
     * Маппер модуля
     * @var
     */
    protected $oEsthemeMapper;

    /**
     * Текущий пользователь
     * @var ModuleUser_EntityUser
     */
    protected $oUserCurrent = NULL;

    /**
     * Инициализация модуля
     */
    public function Init() {

        // Получение текущего пользователя
//        $this->oUserCurrent = $this->User_GetUserCurrent();

        // Получение мапперов
        $this->oEsthemeMapper = Engine::GetMapper('PluginEstheme_ModuleEstheme', 'Estheme');
    }

}