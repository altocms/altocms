<?php

/**
 * ActionAdmin.class.php
 * Файл экшена плагина Estheme
 *
 * @author      Андрей Воронов <andreyv@gladcode.ru>
 * @copyrights  Copyright © 2015, Андрей Воронов
 *              Является частью плагина Estheme
 * @version     0.0.1 от 27.02.2015 08:56
 */
class PluginEstheme_ActionAdmin extends PluginEstheme_Inherit_ActionAdmin {

    /**
     * Абстрактный метод регистрации евентов.
     * В нём необходимо вызывать метод AddEvent($sEventName,$sEventFunction)
     * Например:
     *      $this->AddEvent('index', 'EventIndex');
     *      $this->AddEventPreg('/^admin$/i', '/^\d+$/i', '/^(page([1-9]\d{0,5}))?$/i', 'EventAdminBlog');
     */
    protected function RegisterEvent() {
        parent::RegisterEvent();
        $this->AddEvent('tools-estheme', 'EventEsTheme');
    }

    public function EventEsTheme() {

        $this->sMainMenuItem = 'tools';

        E::ModuleViewer()->Assign('sPageTitle', E::ModuleLang()->Get('plugin.estheme.admin_title'));
        E::ModuleViewer()->Assign('sMainMenuItem', 'tools');
        E::ModuleViewer()->AddHtmlTitle(E::ModuleLang()->Get('plugin.estheme.admin_title'));
        $this->SetTemplateAction('tools/estheme');

        if (getRequest('submit_estheme')) {

            $aData = array();

            $aData['plugin.estheme.color.main'] = getRequest('color_main', '#333333');
            $aData['plugin.estheme.color.light'] = getRequest('color_main_light', '#4d4d4d');
            $aData['plugin.estheme.color.dark'] = getRequest('color_main_dark', '#1a1a1a');
            $aData['plugin.estheme.color.dark_2'] = getRequest('color_main_dark_2', '#0d0d0d');

            Config::WriteCustomConfig($aData);

            $_REQUEST['color_main'] = $aData['plugin.estheme.color.main'];
            $_REQUEST['color_main_light'] = $aData['plugin.estheme.color.light'];
            $_REQUEST['color_main_dark'] = $aData['plugin.estheme.color.dark'];
            $_REQUEST['color_main_dark_2'] = $aData['plugin.estheme.color.dark_2'];

            F::IncludeFile(__DIR__ . '/../../libs/Less.php');

            /** @var Less_Parser $oParser */
            $oParser = new Less_Parser();
            try {
                $sMapPath = C::Get('path.skins.dir') . 'experience_simple/themes/custom/css/theme.custom.css.map';
                $options = array(
                    'sourceMap'        => TRUE,
                    'sourceMapWriteTo' => $sMapPath,
                    'sourceMapURL'     => E::ModuleViewerasset()->AssetFileUrl($sMapPath),
                    'cache_dir'        => __DIR__ . '/../../libs/cache'
                );


                $sCssFileName = Less_Cache::Get(
                    array(C::Get('path.skins.dir') . 'experience_simple/themes/custom/less/theme.less' => C::Get('path.root.web')),
                    $options,
                    array(
                        'dark-blue'      => $aData['plugin.estheme.color.main'],
                        'dark-blue-l-10' => $aData['plugin.estheme.color.light'],
                        'dark-blue-d-10' => $aData['plugin.estheme.color.dark'],
                        'main-gray'      => $aData['plugin.estheme.color.dark_2'],
                    ));
                $sCompiledStyle = file_get_contents( __DIR__ . '/../../libs/cache/' . $sCssFileName );
                F::File_PutContents(C::Get('path.skins.dir') . 'experience_simple/themes/custom/css/theme.custom.css', $sCompiledStyle);


//                $oParser = new Less_Parser($options);
//                $oParser->parseFile(C::Get('path.skins.dir') . 'experience_simple/themes/custom/less/theme.less', C::Get('path.root.web'));
//                $oParser->ModifyVars(array(
//                    'dark-blue'      => $aData['plugin.estheme.color.main'],
//                    'dark-blue-l-10' => $aData['plugin.estheme.color.light'],
//                    'dark-blue-d-10' => $aData['plugin.estheme.color.dark'],
//                    'main-gray'      => $aData['plugin.estheme.color.dark_2'],
//                ));
//                F::File_PutContents(C::Get('path.skins.dir') . 'experience_simple/themes/custom/css/theme.custom.css', $oParser->getCss());
            } catch (Exception $e) {
                $this->ModuleError()->Message_AddErrorSingle($e->getMessage());
            }

            return FALSE;

        }

        $_REQUEST['color_main'] = Config::Get('plugin.estheme.color.main');
        $_REQUEST['color_main_light'] = Config::Get('plugin.estheme.color.light');
        $_REQUEST['color_main_dark'] = Config::Get('plugin.estheme.color.dark');
        $_REQUEST['color_main_dark_2'] = Config::Get('plugin.estheme.color.dark_2');


        return FALSE;

    }

}